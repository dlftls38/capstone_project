import React, { Component } from 'react';
import Container from 'react-bootstrap/Container'
import Row from 'react-bootstrap/Row'
import Col from 'react-bootstrap/Col'
import Nav from 'react-bootstrap/Nav'
export default class About extends Component {
    render() {
      return (
        <div>
          <h1>About area in Dashboard area</h1>
        </div>
      )
    }
}