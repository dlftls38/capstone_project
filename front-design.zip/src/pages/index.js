export { default as Home } from './Home';
export { default as ManageEntity } from './ManageEntity';
export { default as ManageScenario } from './ManageScenario';
export { default as ManageServer } from './ManageServer';
export { default as Settings } from './Settings';